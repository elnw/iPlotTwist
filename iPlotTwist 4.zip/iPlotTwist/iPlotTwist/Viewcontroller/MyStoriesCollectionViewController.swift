//
//  MyStoriesCollectionViewController.swift
//  iPlotTwist
//
//  Created by Developer on 11/19/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import UIKit



class MyStoriesCollectionViewController: HomeCollectionViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
            PlotTwistApi.getStories(token: token, client: client, uid: uid, expiry: expiry, responseHandler: handleResponse, errorHandler: handleError)
            var aux: [Story] = [Story]()
        
        stories.forEach{story in
            if(story.userid == String(userid)){
                aux.append(story)
            }
            
        }
        stories = aux
        
    }

    
}
