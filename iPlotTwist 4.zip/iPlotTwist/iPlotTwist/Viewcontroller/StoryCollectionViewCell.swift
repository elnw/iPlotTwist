//
//  StoryCollectionViewCell.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import UIKit

public class StoryCollectionViewCell: UICollectionViewCell {
    

    @IBOutlet weak var profileImageView: UIImageView!
    
    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var addressLabel: UILabel!
    
    @IBOutlet weak var bodyLabel: UITextView!
    
    @IBOutlet weak var nameLabel: UILabel!
    var story: Story?
    public override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        profileImageView.layer.borderWidth = 1
        profileImageView.layer.masksToBounds = false
        profileImageView.layer.borderColor = UIColor.black.cgColor
        profileImageView.layer.cornerRadius = profileImageView.frame.height/2
        profileImageView.clipsToBounds = true
        
    }
    
    func update(from story: Story) {
        self.story = story
       self.nameLabel.text = "jose"
        self.titleLabel.text = story.title
        self.titleLabel.sizeToFit()
        self.addressLabel.text = story.summary
        self.addressLabel.sizeToFit()
        self.bodyLabel.text = story.body
    }
    
    
    
}
