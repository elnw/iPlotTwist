//
//  RegisterViewController.swift
//  iPlotTwist
//
//  Created by Developer on 11/19/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import UIKit

class RegisterViewController: UIViewController {

    @IBOutlet weak var confirmPasswordTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!

    
    @IBAction func createUserAction(_ sender: UIButton) {
        
        if(emailTextField.text != "" &&  passwordTextField.text != "" && confirmPasswordTextField.text != ""){
            if(   passwordTextField.text == confirmPasswordTextField.text){
                PlotTwistApi.signUp(email: emailTextField.text!, password: passwordTextField.text!, confPassword: confirmPasswordTextField.text!, responseHandler: handleResponse, errorHandler: handleError)
            }else{
                let alertController = UIAlertController(title: "Alerta", message: "Las contrasenas ingresadas no coinciden", preferredStyle: .alert)
                let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
                    print("OK");
                }
                alertController.addAction(action1)
                
                self.present(alertController, animated: true, completion: nil)
            }
        }else{
            let alertController = UIAlertController(title: "Alerta", message: "Debe completar todos los campos", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
                print("OK");
            }
            alertController.addAction(action1)
            
            self.present(alertController, animated: true, completion: nil)
        }
        
        
    }
    
    func handleResponse(response: RegisterResponse , headers: [String : String]) {
        
        
            let alertController = UIAlertController(title: "Alerta", message: "Su usuario fue creado correctamente", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
                self.performSegue(withIdentifier: "goBackLogin", sender: nil);
            }
            alertController.addAction(action1)
            
            self.present(alertController, animated: true, completion: nil)
            
            /*confirmPasswordTextField.text = ""
            passwordTextField.text = ""
            emailTextField.text = ""*/
            
        
        //print("que paso amiguito")
        
       /* responseLogin = response
        headerResponse = headers*/
        
        
        
        
        
    }
    
    @IBAction func returnButton(_ sender: UIButton) {
        self.performSegue(withIdentifier: "back", sender: nil)
    }
    func handleError(error: Error) {
        
        let alertController = UIAlertController(title: "Alerta", message: "Ocurrio un problema al crear su usuario", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
            print("OK");
        }
        alertController.addAction(action1)
        
        self.present(alertController, animated: true, completion: nil)
        
        let message = "Error while requesting Sources: \(error.localizedDescription)"
        print(message)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
