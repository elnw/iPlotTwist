//
//  WriteViewController.swift
//  iPlotTwist
//
//  Created by Developer on 11/17/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import UIKit

class WriteViewController: UIViewController {

    var token: String = ""
    var uid: String = ""
    var client: String = ""
    var expiry: String = ""
    var userid: Int = 0
    
    @IBOutlet weak var titleTextField: UITextField!
    
    @IBOutlet weak var bodyTextView: UITextView!
    @IBOutlet weak var addressTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
       bodyTextView.placeholder = "Ingrese su historia"
        bodyTextView.layer.borderWidth = 1.0
        bodyTextView.layer.borderColor = UIColor.darkGray.cgColor
        // Do any additional setup after loading the view.
      
       
        
       
        
    }
    
    @IBAction func createStoryAction(_ sender: Any) {
        if( titleTextField.text != "" && bodyTextView.text != "" && addressTextField.text != ""){
            
            PlotTwistApi.createStory(token: token, uid: uid, client: client, expiry: expiry, title: titleTextField.text!, summary: "", body: bodyTextView.text!, address: addressTextField.text!, userid: userid, responseHandler: handleResponse, errorHandler: handleError)
        }else{
            let alertController = UIAlertController(title: "Alerta", message: "Debe completar todos los campos", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
                print("OK");
            }
            alertController.addAction(action1)
            
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    
    
 
    
    
    

    
    func handleResponse(response: createStoryResponse, headers: [String : String] ) {
        
        if (response.id != nil ){
            let alertController = UIAlertController(title: "Alerta", message: "Su historia fue publicada con exito", preferredStyle: .alert)
            let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
                print("OK");
            }
            alertController.addAction(action1)
            
            self.present(alertController, animated: true, completion: nil)
            titleTextField.text = ""
            bodyTextView.text = ""
            addressTextField.text = ""
            bodyTextView.placeholder = "Ingrese su historia"
        }
       
        
    }
    
    func handleError(error: Error) {
        
        let alertController = UIAlertController(title: "Alerta", message: "Error while creating Stories", preferredStyle: .alert)
        let action1 = UIAlertAction(title: "OK", style: .default) { (action:UIAlertAction) in
            print("OK");
        }
        alertController.addAction(action1)
        
        self.present(alertController, animated: true, completion: nil)
        
        let message = "Error while creating Stories:\(error.localizedDescription)"
        print(message)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
