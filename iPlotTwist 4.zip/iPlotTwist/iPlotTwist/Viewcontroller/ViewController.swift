//
//  ViewController.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func loginAction(_ sender: Any) {
        performSegue(withIdentifier: "showLogin", sender: self)
    }
    
    @IBAction func registerAction(_ sender: Any) {
        performSegue(withIdentifier: "showRegistration", sender: self)
    }
}

