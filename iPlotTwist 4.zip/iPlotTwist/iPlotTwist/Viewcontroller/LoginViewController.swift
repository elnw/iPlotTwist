//
//  LoginViewController.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var loginButtom: UIButton!
    
    var responseLogin: LoginResponse = LoginResponse(data: User(id: Int("0")! , email: "", provider: "", uid: "", allowPasswordChange: false, name: "", nickname: "", image: "" ))
    
    var headerResponse: [String : String]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
  
    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "succesfulLogin"){
            /*let tabCtrl: UITabBarController = segue.destination as! UITabBarController
            let destination = tabCtrl.viewControllers![0] as! HomeCollectionViewController*/
            
            if let barVC = segue.destination as? UITabBarController {
                barVC.viewControllers?.forEach {
                    if let vc = $0 as? HomeCollectionViewController {
                        if let token = headerResponse["access-token"], let client = headerResponse["client"], let uid = headerResponse["uid"] , let expiry = headerResponse["expiry"]
                        {
                            vc.token = token
                            vc.client = client
                            vc.uid = uid
                            vc.expiry = expiry
                            vc.userid = responseLogin.data.id
                        }
                    }
                    
                    if let vc2 = $0 as? WriteViewController {
                        if let token = headerResponse["access-token"], let client = headerResponse["client"], let uid = headerResponse["uid"] , let expiry = headerResponse["expiry"]{
                           vc2.token = token
                           vc2.client = client
                           vc2.uid = uid
                           vc2.expiry = expiry
                           vc2.userid = responseLogin.data.id
                        }
                    }
                    if let vc3 = $0 as? HomeCollectionViewController {
                        if let token = headerResponse["access-token"], let client = headerResponse["client"], let uid = headerResponse["uid"] , let expiry = headerResponse["expiry"]
                        {
                            vc3.token = token
                            vc3.client = client
                            vc3.uid = uid
                            vc3.expiry = expiry
                            vc3.userid = responseLogin.data.id
                        }
                    }
                    
                }
            }
            
            
            
           // let destination = segue.destination as! HomeCollectionViewController
            
        
            
              //"hblLT5Py3ZPrJ3jTsJXG7g"
              //"FaC2AYfHq20lmDTAbBDLcg"
             //"jyellow363@gmail.com"
            //"1543530387"
            
            
        }
    }
 
    @IBAction func validateLogin(_ sender: Any) {
        
        if(emailTextField.text != "" && passwordTextField.text != ""){
             PlotTwistApi.signIn(email: emailTextField.text!, password: passwordTextField.text!, responseHandler: handleResponse, errorHandler: handleError)
        }
        
       
        
        
        
        
    }
    
    func handleResponse(response: LoginResponse , headers: [String : String]) {
        
            responseLogin = response
            headerResponse = headers
            self.performSegue(withIdentifier: "succesfulLogin", sender: nil)
        
        
        
        
    }
    
    func handleError(error: Error) {
        let message = "Error while requesting Sources: \(error.localizedDescription)"
        print(message)
    }
    
    
    
    
}
