//
//  LoginResponse.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import Foundation

struct LoginResponse : Decodable { 
    let data: User
}


