//
//  PlotTwistApi.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import Foundation
import Alamofire
import AlamofireObjectMapper
import os
import SwiftyJSON

extension Request {
    public func debugPrint() -> Self {
        Swift.debugPrint("-- Request ---")
        Swift.debugPrint(self)
        Swift.debugPrint("---End Request---")
        return self
    }
}


class PlotTwistApi{
    static let baseUrl = "https://thawing-journey-89790.herokuapp.com"
    static let loginUrl = "\(baseUrl)/auth/sign_in"
    static let storiesUrl = "\(baseUrl)/stories"
    static let registerUrl = "\(baseUrl)/auth"
    
    static private func post<T: Decodable>(from urlString: String,parameters: [String :  String], headers: [String :  String],responseType: T.Type , responseHandler: @escaping (((T, [String : String] ) -> Void)) , errorHandler: @escaping (Error)-> Void){
        guard let url = URL(string: urlString) else {
            let message = "Error on URL"
            os_log("%@",message)
            return
        }
        
        Alamofire.request(url, method: .post, parameters: parameters, encoding: JSONEncoding.default).validate().debugPrint().responseJSON(completionHandler: { response in
            switch response.result {
            case .success(_):
                do{
                    
                    let decoder = JSONDecoder()
                    
                    if let data = response.data{
                        let dataResponse = try decoder.decode(responseType, from: data)
                        let headers = response.response?.allHeaderFields as? [String :  String]
                        responseHandler(dataResponse, headers!)
                    }
                    
                } catch{
                    errorHandler(error)
                }
                
            case .failure(let error):
                
                errorHandler(error)
            }
        })
        
        
    }
    
  
    
    
    
    
    static func signIn(email : String, password: String , responseHandler: @escaping(LoginResponse, [String : String])->Void, errorHandler: @escaping(Error) -> Void){
        let parameters = ["email" : email, "password" : password]
        //let headers = ["cache-control" : "no-cache","Accept" : "*/*", "Host" : "thawing-journey-89790.herokuapp.com", "accept-encoding" : "gzip, deflate", "content-length" : "" ]
        //investigar como se capturan los headers
        
        //let urlString = loginUrl.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed)
        //self.post(from: urlString!, parameters: parameters, headers: ["" : ""], responseType: loginResponse.self, responseHandler: responseHandler, errorHandler: errorHandler)
        
        let headers  = ["Content-Type": "application/x-www-form-urlencoded"]
        
        
        Alamofire.request(loginUrl, method: .post, parameters: parameters , encoding: URLEncoding.default, headers: headers).debugPrint().responseString { (response) in
            
            let statusResponse = response.response?.statusCode
            //.debugPrint()
            switch response.result {
            case .success(let value):
                do{
                    if statusResponse == 200 {
                        //let jsonObject = JSON(value)
                        let headers = response.response?.allHeaderFields as? [String :  String]
                       
                       /* let dataResponse = JSON(value)
                        let answer = LoginResponse(data: User(name: dataResponse["name"].string, nickname: dataResponse["nickname"].string, email: dataResponse["email"].string, id: dataResponse["id"].string))*/
                        
                       let decoder = JSONDecoder()
                        
                        let json = """
                    {
                         "data": {
                                "id": "2",
                                 "email": "jyellow363@gmail.com",
                                 "provider": "email",
                                 "uid": "jyellow363@gmail.com",
                                 "allow_password_change": "false",
                                 "name": "null",
                                 "nickname": "null",
                                 "image": "null"
                                }
                    }
                    """.data(using: .utf8)!
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        let dataResponse = try decoder.decode(LoginResponse.self, from: value.data(using: .utf8)!)
                        //let dataResponse = try decoder.decode(LoginResponse.self, from: json)
                        responseHandler(dataResponse, headers!)
                        
                        //responseHandler(dataResponse, headers!)
                        
                    }
                } catch {
                    errorHandler(error)
                }
                
                
                
                
            case .failure(let error):
                errorHandler(error)
            }
            
        }
        
        
    }
    
    static func createStory(token: String, uid : String, client: String, expiry: String, title: String, summary: String, body: String, address: String, userid: Int, responseHandler: @escaping ((createStoryResponse, [String : String])->Void), errorHandler: @escaping (Error) -> Void){
        let parameters = ["title" : title, "summary" : address,"body" : body,"userid" : String(userid)]
        let headers = ["token" : token,"uid" : uid,"client" : client,"expiry" : expiry]
        
        self.post(from: storiesUrl, parameters: parameters,headers: headers ,responseType: createStoryResponse.self, responseHandler: responseHandler, errorHandler: errorHandler)
        
    }
    
    static func signUp( email: String, password: String, confPassword: String, responseHandler: @escaping ((RegisterResponse, [String : String])->Void), errorHandler: @escaping (Error) -> Void){
        let parameters = ["email" : email, "password" : password, "password_confirmation" : confPassword, "confirm_success_url" : "www.google.com"]
        
        
        self.post(from: registerUrl, parameters: parameters,headers: ["" : ""], responseType: RegisterResponse.self, responseHandler: responseHandler, errorHandler: errorHandler)
        
    }
    
    static func getStories( token: String, client: String, uid: String, expiry: String, responseHandler: @escaping (([Story]?)->Void), errorHandler: @escaping (Error) -> Void){
        let headers: HTTPHeaders = ["access-token" : token , "client" : client, "uid" : uid, "expiry" : expiry]
        
        
        Alamofire.request(storiesUrl , headers: headers).responseArray(completionHandler: { (response: (DataResponse<[Story]>)) in
            switch response.result{
            case .success(_):
                    let array = response.result.value
                    responseHandler(array)
              
            case .failure(let error):
                errorHandler(error)
            }
            
            
        })
        
        
    }
    
    
    
    
    
    
}
