//
//  Story.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import Foundation
import ObjectMapper

class Story : Mappable{
    var title: String?
    var summary: String?
    var userid : String?
    var body : String?
    var latitude : String?
    var longitude : String?
    
    required init?(map: Map){
        
    }
    
    func mapping(map: Map) {
        title <- map["title"]
        summary <- map["summary"]
        userid <- map["userid"]
        body <- map["body"]
        latitude <- map["latitude"]
        longitude <- map["longitude"]
    }
    
}
