//
//  User.swift
//  iPlotTwist
//
//  Created by Developer on 11/15/18.
//  Copyright © 2018 UPC. All rights reserved.
//

import Foundation

struct User : Decodable{
    var id: Int
    var email:String
    var provider: String
    var uid: String
    var allowPasswordChange: Bool
    var name: String?
    var nickname: String?
    var image: String?
    
    enum CodingKeys: String, CodingKey {
        case id, email, provider, uid
        case allowPasswordChange = "allow_password_change"
        case name, nickname, image
    }
    

    
    
}

